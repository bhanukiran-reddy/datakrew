export default function Footer() {
    return (
        <footer>
            <div className="container">
                <div className="footerContent">
                    <div className="footerContentLeft">
                        <h3>Footer</h3>
                    </div>
                </div>
            </div>
        </footer>
    )
}